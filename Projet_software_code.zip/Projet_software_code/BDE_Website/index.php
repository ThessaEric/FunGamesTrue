
  <?php include('header.php'); ?>
    
       <div id="accueil">
           <img id="img-accueil" src="./assets/images/autres/accueil1.jpeg" width="100%" height="675px">
           <p>Bienvenue-sur notre site</p>

    </div>
        <div id="toutac">
    <div id="icon-acceuil">
        <div>
            <a href="store.php"><i class="fas fa-store"></i><br>Accéder à la boutique</a>
        </div>
        
    </div>
      <?php include('footer.php'); ?>       
    </div>
    
    

